#include "hashtable.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
using namespace cop4530;

void menu();
string modify(string a);

int main(int argc, char*argv[])
{
if(argc==1)
{	
int capacity;
char choice;
char filename[32];
char filename2[32];
char word[32];
char word2[32];
char word3[32];
cout << "Enter preferred hash table capacity: ";
if(isdigit(cin.peek()))
cin >> capacity;
else
capacity=0;

HashTable<string> sentence(capacity);
cout << sentence.transformation() << endl;

do
{
menu();
cin >> choice;
cin.ignore(100,'\n');

if(choice == 'l')
{
cout << "Enter dictionary filename to load from: ";
cin >> filename;
sentence.load(filename);
	if(sentence.load(filename)==true)
		cout << "Dictionary loaded successfully." << endl;
	else if(sentence.load(filename)==false)
		cout << "Cannot open file " << filename << endl;
}
else if(choice == 'a')
{
cout << "Enter word: ";
cin >> word;
cout << endl;

if(sentence.contains(word)==false)
{
	sentence.insert(word);
	cout << "Word " << word << " added." << endl;
}
else
	cout << "*****: Word already exists. Could not add." << endl;
}
else if(choice == 'r')
{
cout << "Enter word: ";
cin >> word2;
	if(sentence.remove(word2)==true)
		cout << "Word " << word2 << " deleted." << endl;
	else
		cout << "*****: Word not found. Could not delete" << endl;
}
else if(choice =='c')
{
sentence.clear();
}
else if(choice == 'f')
{
cout << "Enter word: ";
cin >> word3;
cout << endl;
	if(sentence.contains(word3)==true)
		cout << "Word " << word3 <<  " found." << endl;
	else
		cout << "Word " << word3 << " not found." << endl;
}
else if(choice == 'd')
{
sentence.dump();
}
else if(choice == 's')
{
cout << endl;
cout << "Size of hashtable: " << sentence.getsize() << endl;
}
else if(choice == 'w')
{
cout << "Enter dictionary file name to write to: ";
cin >> filename2;

if(sentence.write_to_file(filename2)==true)
	cout << "Written successfully." << endl;
else
cout << "Cannot open file to write." << endl;
}
else if(choice == 'x')
{
break;
}
else
{
choice = 'l';
cout << "*****Error: Invalid entry.  Try again." << endl;
}

}while(choice == 'l' || choice == 'a' || choice == 'r' || choice == 'c' || choice == 'f' || choice == 'd' || choice == 's' || choice == 'w');
}

else if(argc==4)
{
ifstream op;
string ss;
ofstream finish;
finish.open(argv[3]);
HashTable<string> sentence2;
sentence2.load(argv[1]);
char choice2;
cout << sentence2.initialreturn() << endl;

op.open(argv[2]);

	while(getline(op,ss))
	{
	istringstream s(ss);
	string x;
	string ftemp;
	vector<string>container;
	int counter5=-1;
	string temp5;
	container.clear();
		while(s>>x)
		{
			if(sentence2.contains(modify(x)) == false)
			 {
				counter5=0;
				string temp = x;
				for(int f=0; f<x.length();f++)
					ftemp += toupper(x[f]);
				ftemp += " ";
				
					for(int i=0; i<temp.length();i++)
					{
						for(char j = 'a'; j<='z';j++)
						{
						if(temp[i]==isupper(temp[i]))
							temp[i]=toupper(temp[j]);
						else
							temp[i]=j;
							if(sentence2.contains(modify(temp)) && counter5!=10)
							{	
								container.push_back(temp);
								counter5++;
								
								if(counter5==10)
									break;
							}
						}
					temp = x;
					temp5 = x;
					if(counter5==10)
						break;
					}
			}
			else if(sentence2.contains(modify(x)) == true)
			{
			ftemp += x;
			ftemp += " ";
			}
		//for(int i=0;i<container.size();i++)
		//	cout << container[i] << endl;
		}
			bool test;
			do
			{
			string choice2;
			int num;
				if(counter5>-1)
				{
				cout << ftemp << endl;
				cout << "====================================" << endl;
				for(int i=0; i<container.size();i++)
				cout << i << "): " << modify(container[i]) << endl;
				cout << "n (no change):" << endl;
				cout << "====================================" << endl;
				cout << "Your choice: ";
				cin >> choice2;
				num = choice2[0] - '0';
					if(choice2[0]!='n' && !isdigit(choice2[0]))
					{
					cout << "invalid choice" << endl;
					test = 0;
					}
					else if(choice2[0]!='n' && num>=container.size())
					{
					cout << "invalid choice" << endl;
					test = 0;
					}
					else if(choice2[0]=='n')
					{
					test=1;
					finish << ss << endl;
					}
					else if(isdigit(choice2[0]))
					{
					test=1;
					ss.replace(ss.find(temp5),temp5.length(),container[num]);
					finish << ss << endl;
					}
				}
				else
				{
				finish << ss << endl;
				}
			}while(test==false);
		
	}
finish.close();
}
else
{
cout << argv[0] << " dictionary check_file output_file" << endl;
}

return 0;
}

void menu()
{
	cout << "\n\n";
	cout << "l - Load Dictionary From File" << endl;
	cout << "a - Add Word" << endl;
	cout << "r - Remove Word" << endl;
	cout << "c - Clear HashTable" << endl;
	cout << "f - Find Word" << endl;
	cout << "d - Dump HashTable" << endl;
	cout << "s - HashTable Size" << endl;
	cout << "w - Write to File" << endl;
	cout << "x - Exit program" << endl;
	cout << "\nEnter choice : ";
}

string modify(string a)
{
string x = a;
                 if(!isalpha(x.back()))
                        x.pop_back();

                for(int i=0;i<x.length();i++)
                        x[i] = tolower(x[i]);
return x;
}
